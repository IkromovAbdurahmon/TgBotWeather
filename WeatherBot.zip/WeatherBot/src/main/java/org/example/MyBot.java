package org.example;

import org.example.service.BotServiceImpl;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.TelegramBotsApi;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import org.telegram.telegrambots.updatesreceivers.DefaultBotSession;

public class MyBot extends TelegramLongPollingBot {
    // import classes
    BotServiceImpl service = new BotServiceImpl();

    @Override
    public void onUpdateReceived(Update update) {
        if (update.hasMessage()) {
            long chatId = update.getMessage().getChatId();
            String text = update.getMessage().getText();
            System.out.println("Received message: " + text); // Debugging uchun
            if (text.equals("/start")) {
                try {
                    execute(service.getButton(chatId));
                    System.out.println("Start command executed"); // Debugging uchun
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            } else {
                sendMessage(service.getFunctions(text), chatId);
            }
        }
    }


    public void sendMessage(String text,long chatId){
        SendMessage sendMessage = new SendMessage();
        sendMessage.setChatId(chatId);
        sendMessage.setText(text);
        try {
            execute(sendMessage);
        } catch (TelegramApiException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String getBotUsername() {
        return "@AlJabr_bot";
    }

    @Override
    public String getBotToken() {
        return "7573111096:AAFKAJeAYnjcgn4ZyH8bTDxBINyrBap6RCo";
    }

    public static void main(String[] args) {
        try {
            TelegramBotsApi api = new TelegramBotsApi(DefaultBotSession.class);
            api.registerBot(new MyBot());
            System.out.println("Bot started");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
