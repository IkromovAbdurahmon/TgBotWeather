package org.example.service;

import org.telegram.telegrambots.meta.api.methods.send.SendMessage;

public interface BotService {
    SendMessage getButton(long chatId);
    String getFunctions(String text);
}
