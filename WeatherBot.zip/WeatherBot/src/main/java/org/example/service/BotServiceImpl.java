package org.example.service;

import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardButton;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardRow;

import java.util.ArrayList;
import java.util.List;

public class BotServiceImpl implements BotService{
    HttpServiceImpl service = new HttpServiceImpl();
    @Override
    public SendMessage getButton(long chatId) {
        SendMessage sendMessage = new SendMessage();
        sendMessage.setChatId(chatId);
        sendMessage.setText("Button spawned");
        ReplyKeyboardMarkup replyKeyboardMarkup = new ReplyKeyboardMarkup();
        List<KeyboardRow> rows = new ArrayList<>();
        KeyboardRow row1 = new KeyboardRow();
        KeyboardRow row2 = new KeyboardRow();
        row1.add(new KeyboardButton("Weather on C"));
        row1.add(new KeyboardButton("Weather on F"));
        row2.add(new KeyboardButton("Region and Country"));
        row2.add(new KeyboardButton("Local_Time"));
        rows.add(row1);
        rows.add(row2);
        replyKeyboardMarkup.setKeyboard(rows);
        sendMessage.setReplyMarkup(replyKeyboardMarkup);

        return sendMessage;
    }

    @Override
    public String getFunctions(String text) {
        return switch (text) {
            case "Weather on C" -> service.getWeather().getCurrent().getTempC().toString();
            case "Weather on F" -> service.getWeather().getCurrent().getTempF().toString();
            case "Region and Country" ->
                    service.getWeather().getLocation().getRegion() + " and " + service.getWeather().getLocation().getCountry();
            case "Local_Time" -> service.getWeather().getLocation().getLocaltime();
            default -> "Error";
        };
    }
}
