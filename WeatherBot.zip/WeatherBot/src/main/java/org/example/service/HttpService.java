package org.example.service;

import org.example.moduls.Weather;

public interface HttpService {
    Weather getWeather();
}
