package org.example.service;

import com.google.gson.Gson;
import org.example.moduls.Weather;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class HttpServiceImpl implements HttpService {
    String baseUrl = "https://api.weatherapi.com/v1/current.json?key=b0090229bc654e8a9c4155928253001&q=Tashkent&aqi=yes";
    Gson gson = new Gson();

    @Override
    public Weather getWeather() {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            URL url = new URL(baseUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                stringBuilder.append(line);
            }
            bufferedReader.close();

            // Parse the JSON response to Weather object
            Weather weather = gson.fromJson(stringBuilder.toString(), Weather.class);
            return weather;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
