package org.example;

import org.example.service.HttpServiceImpl;

public class Main {
    public static void main(String[] args) {
        HttpServiceImpl service = new HttpServiceImpl();
        System.out.println(service.getWeather());
    }
}