package org.example.moduls;

import com.google.gson.annotations.SerializedName;

public class AirQuality{

	@SerializedName("no2")
	private Object no2;

	@SerializedName("o3")
	private Object o3;

	@SerializedName("us-epa-index")
	private int usEpaIndex;

	@SerializedName("so2")
	private Object so2;

	@SerializedName("pm2_5")
	private Object pm25;

	@SerializedName("pm10")
	private Object pm10;

	@SerializedName("co")
	private Object co;

	@SerializedName("gb-defra-index")
	private int gbDefraIndex;

	public void setNo2(Object no2){
		this.no2 = no2;
	}

	public Object getNo2(){
		return no2;
	}

	public void setO3(Object o3){
		this.o3 = o3;
	}

	public Object getO3(){
		return o3;
	}

	public void setUsEpaIndex(int usEpaIndex){
		this.usEpaIndex = usEpaIndex;
	}

	public int getUsEpaIndex(){
		return usEpaIndex;
	}

	public void setSo2(Object so2){
		this.so2 = so2;
	}

	public Object getSo2(){
		return so2;
	}

	public void setPm25(Object pm25){
		this.pm25 = pm25;
	}

	public Object getPm25(){
		return pm25;
	}

	public void setPm10(Object pm10){
		this.pm10 = pm10;
	}

	public Object getPm10(){
		return pm10;
	}

	public void setCo(Object co){
		this.co = co;
	}

	public Object getCo(){
		return co;
	}

	public void setGbDefraIndex(int gbDefraIndex){
		this.gbDefraIndex = gbDefraIndex;
	}

	public int getGbDefraIndex(){
		return gbDefraIndex;
	}

	@Override
 	public String toString(){
		return 
			"AirQuality{" + 
			"no2 = '" + no2 + '\'' + 
			",o3 = '" + o3 + '\'' + 
			",us-epa-index = '" + usEpaIndex + '\'' + 
			",so2 = '" + so2 + '\'' + 
			",pm2_5 = '" + pm25 + '\'' + 
			",pm10 = '" + pm10 + '\'' + 
			",co = '" + co + '\'' + 
			",gb-defra-index = '" + gbDefraIndex + '\'' + 
			"}";
		}
}